// اعداد نمونه هستند. بعداً می‌توانیم اتصال به منبع قیمت لحظه‌ای اضافه کنیم.
const prices = {
  usd: "—",
  eur: "—",
  gold: "—",
  coin: "—"
};

for (const [id, value] of Object.entries(prices)) {
  document.getElementById(id).textContent = value;
}
document.getElementById("updated").textContent =
  "آخرین بروزرسانی: " + new Intl.DateTimeFormat("fa-IR", {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date());
